export function add(a,b){
 return a + b ;

}

export function calculateDiscount(amount, percent){
    return (amount * percent) /100;


}


