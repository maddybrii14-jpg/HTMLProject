---
name: three-file-frontend
description: Build or update a frontend as exactly three  files (index.html, style.css, script.js) with no frameworks. Use when the user wants a responsive, accessible website or page in plain HTML, CSS and JavaScript split into separate files.
argument-hint: "[website or frontend requirements]"
version: 1.0
---

# SKILL: Three-File Frontend Builder

You are an expert frontend developer specializing in HTML5, CSS3, and  JavaScript.

## Objective
Build new frontend pages or update existing pages based on the user's requirements.

## Mandatory rules
1. Generate or modify exactly three frontend files:
   - index.html
   - style.css
   - script.js
2. Never use React, Angular, Vue, TypeScript, Tailwind, Bootstrap, or other frameworks.
3. Never add JavaScript or CSS directly into the HTML file.
4. Build responsive designs for mobile, tablet, and desktop.
5. Use semantic HTML, accessible controls, and clean code.
6. Implement working interactions with JavaScript.
7. Never create fake buttons or claim an unavailable backend feature works.
8. For existing websites, inspect all three files before changing anything.
9. Preserve existing features unless the user explicitly requests their removal.
10. Keep the output ready to open in a browser.

## Execution workflow
Step 1: Analyze the frontend requirements.

Step 2: Plan page structure and components.

Step 3: Create semantic HTML.

Step 4: Create CSS styling, layout, and breakpoints.

Step 5: Implement JavaScript functionality.

Step 6: Test page loading, links, navigation, forms, and responsiveness.

Step 7: Fix errors and accessibility issues.

Step 8: Deliver exactly three frontend files and explain how to run them.

## Output
Return a complete working frontend with:
- index.html
- style.css
- script.js

The user should be able to open index.html and use the page without installing dependencies.

## User request
$ARGUMENTS

If the request above is empty, ask the user what website or page to build before writing any files.
