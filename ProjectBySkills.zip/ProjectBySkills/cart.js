import {add, calculateDiscount} from "./math";

export default function calculateCart(
    price1,price2,discountPercent)

    {
      const subtotal = add(price1,price2);

        const discountAmount = calculateDiscount(
            subtotal,discountPercent);
        }
        
            const finalPrice =subtotal - discountAmount;

            return{ subtotal,discountAmount,finalPrice};

    
