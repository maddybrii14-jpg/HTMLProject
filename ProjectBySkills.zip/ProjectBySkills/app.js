
import calculateCart from "./cart.js";

const product1 = document.getElementById("product1");
const product2 = document.getElementById("product2");
const discount = document.getElementById("discount");

const calculateBtn = document.getElementById(
  "calculateBtn"
);

const subtotalText = document.getElementById("subtotal");
const discountText = document.getElementById(
  "discountAmount"
);
const finalPriceText = document.getElementById(
  "finalPrice"
);

function displayCart() {
  const price1 = Number(product1.value);
  const price2 = Number(product2.value);
  const percent = Number(discount.value);

  if (
    !Number.isFinite(price1) ||
    !Number.isFinite(price2) ||
    !Number.isFinite(percent) ||
    price1 < 0 ||
    price2 < 0 ||
    percent < 0 ||
    percent > 100
  ) {
    alert("Enter valid prices and a discount from 0 to 100.");
    return;
  }

  const result = calculateCart(
    price1,
    price2,
    percent
  );

  subtotalText.textContent =
    "$" + result.subtotal.toFixed(2);

  discountText.textContent =
    "$" + result.discountAmount.toFixed(2);

  finalPriceText.textContent =
    "$" + result.finalPrice.toFixed(2);
}

calculateBtn.addEventListener("click", displayCart);

displayCart();
